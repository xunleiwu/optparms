import locale
import os
import sys
import math
import numpy as np
import pandas as pd
import datetime
import csv
#from datetime import datetime
from decimal import Decimal
import talib
   
# Load and transform a CSV stock data set downloaded from Investing.com.
# Sample: LoadTable('C:\\Users\\lampa\\Documents\\TrunkCover\\data\\', '上证指数历史数据.csv')
def LoadTable(dataPath, fileName):   
    locale.setlocale(locale.LC_CTYPE, 'chinese')
    
    #https://jessesw.com/XG-Boost/
    #dataPath = 'C:\\Users\\lampa\\Documents\\TrunkCover\\data\\'
    
    #Load data - data format 
    # "日期","最新","开盘","高","低","交易量","百分比变化"
    # "2009年1月5日","1,880.72","1,849.02","1,880.72","1,844.09","6.71B","3.29"
    
    #fileName = dataPath + '上证指数历史数据.csv'
    fileName = dataPath + fileName
    dTrain = pd.read_csv(open(fileName, 'rb'), header=0)
    
    #Below are two final rows from such dataset.
    #"","","","","","",""
    #"","最高:5,178.19","最低:1,844.09","差价:3,334.10","平均:2,779.30","百分比变化:80.76"
    dTrain = dTrain[dTrain['日期'].notnull()]
    
    #dTest = pd.read_csv(dataPath + 'adult\\adult.test', header = None, skiprows = 1) # Make sure to skip a row for the test set
    #dTrainOriShape = dTrain.shape
    #dTestOriShape = dTest.shape
    
    ##Add column label explicitly
    #col_labels = ["日期","最新","开盘","高","低","交易量","百分比变化"]
    #dTrain.columns = col_labels
    #dTest.columns = col_labels
    
    #Convert '2009年1月5日' to 2009-1-5 datetime object
    dTrain['日期'] = pd.to_datetime(dTrain['日期'], format='%Y年%m月%d日', errors='ignore')
    dTrain['日期'] = dTrain['日期'].dt.date
    
    #Convert "1,880.72" to 1880.72 as float
    dTrain['最新'] = pd.to_numeric(dTrain['最新'].str.replace(',', ''), downcast='float', errors='ignore')
    dTrain['开盘'] = pd.to_numeric(dTrain['开盘'].str.replace(',', ''), downcast='float', errors='ignore')
    dTrain['高'] = pd.to_numeric(dTrain['高'].str.replace(',', ''), downcast='float', errors='ignore')
    dTrain['低'] = pd.to_numeric(dTrain['低'].str.replace(',', ''), downcast='float', errors='ignore')
    #'百分比变化' is not yet used.
    #pd.to_numeric(dTrain['百分比变化'].str.replace(',', ''), downcast='float', errors='ignore')   
    
    #Convert "6.71B" to 6.71e+9
    tpVol = pd.DataFrame.copy(dTrain['交易量'])
    d = dict(K=10**3, M=10**6, B=10**9, T=10**12, P=10**15)
    i = 0
    for vol in dTrain['交易量']:
        num, mag = vol[:-1], vol[-1]
        tpVol[i] = Decimal(num) * d[mag]
        i = i + 1
    dTrain['交易量'] = tpVol
    
    dTrain = dTrain.rename(index=str, columns={'日期':'Date', '最新':'Close', '开盘':'Open', '高':'High', '低':'Low', '交易量':'Volume'})
    list(dTrain)#Verify the column names have been changed.
    #Date,Open,High,Low,Close,Volume
    
    return dTrain
# =============================================================================
# 
#     class parms:
#         def __init__(self):
#             self.macd = 8, 30, 9
#             self.kdj = 9, 9, 9
#             self.ma = 10, 30, 60, 90
#             self.volume = 5, 10
#     
#     s = parms()
# 
# =============================================================================


# http://www.qieying.com/gupiao/rumen/65.html
#def KDJ(f, closePeriod=9, lowPeriod=9, highPeriod=9): 
#    C = np.asarray(f['Close'])
#    L = f['Low'].rolling(closePeriod).min()
#    H = f['High'].rolling(closePeriod).max()
#    
#    RSV = (C - L) / (H - L) * 100
#    
#    # Initialize K and D with 50
#    K = np.full(C.shape, 50, dtype=float)
#    D = np.full(C.shape, 50, dtype=float)
#    
#    alphaK = (lowPeriod - 1) / lowPeriod
#    betaK = 1 / lowPeriod
#    alphaD = (highPeriod - 1) / highPeriod
#    betaD = 1 / highPeriod
#    # First couple of day's RSV values are NaN
#    for i in range(max(lowPeriod, highPeriod), len(C)):
#        K[i] = alphaK * K[i-1] + betaK * RSV[i]
#        D[i] = alphaD * D[i-1] + betaD * K[i]
#        
#    J = (3 * K) - (2 * D)
#    return K, D, J

def KDJ(f, closePeriod=9, lowPeriod=9, highPeriod=9): 
    C = np.asarray(f['Close'])
    L = f['Low'].rolling(closePeriod).min()
    H = f['High'].rolling(closePeriod).max()
    
    RSV = (C - L) / (H - L) * 100
    
    # Initialize K and D with 50
    K = np.full(C.shape, 50, dtype=float)
    D = np.full(C.shape, 50, dtype=float)
    J = np.full(C.shape, 50, dtype=float)
    #signal = np.full(C.shape, '', dtype=str)
    signal = np.chararray(C.shape, itemsize=4, unicode=True)
    signal[:] = ''
    
    alphaK = (lowPeriod - 1) / lowPeriod
    betaK = 1 / lowPeriod
    alphaD = (highPeriod - 1) / highPeriod
    betaD = 1 / highPeriod
    # First couple of day's RSV values are NaN
    for i in range(max(lowPeriod, highPeriod), len(C)):
        K[i] = alphaK * K[i-1] + betaK * RSV[i]
        D[i] = alphaD * D[i-1] + betaD * K[i]
        J[i] = (3 * K[i]) - (2 * D[i])
    
#        if math.isnan(K[i]) or math.isnan(D[i]) or math.isnan(J[i]):
#            signal[i] = ''
#            continue  
        
        if (J[i] > K[i]) and (K[i] > D[i]):
            signal[i] = 'BUY'
        elif (J[i] <= K[i]) and (K[i] <= D[i]):
            signal[i] = 'SELL'
        else:
            signal[i] = 'HOLD'
        #print('Date, Signal, Close, J, K, D =', f['Date'][i], signal[i], f['Close'][i], J, K, D)
    
    return K, D, J, signal


#Derive K, D, J, and KDJ_Signal
def KDJSignal(f, parms):
    #kdjP = {'closePeriod': parms.kdj[0], 'lowPeriod': parms.kdj[1], 'highPeriod': parms.kdj[2]}
    #kdjColBase = 'KDJ(' + str(kdjP['closePeriod']) + ',' + str(kdjP['lowPeriod']) + ',' + str(kdjP['highPeriod']) + ')'
    kdjColBase = 'KDJ'
    # Prepare new columns
    if (kdjColBase + '_K') not in f:
        # Make sure '_TempK_' does not exist in f!!!  
        f = f.assign(_Temp0_ = pd.Series.empty)
        f = f.assign(_Temp1_ = pd.Series.empty)
        f = f.assign(_Temp2_ = pd.Series.empty)
        f = f.assign(_Temp3_ = pd.Series.empty)
        f.rename(index=str, columns={'_Temp0_' : (kdjColBase + '_K'), 
                                     '_Temp1_' : (kdjColBase + '_D'), 
                                     '_Temp2_' : (kdjColBase + '_J'),
                                     '_Temp3_' : (kdjColBase + '_Signal'),}, inplace=True)        
        
    f[kdjColBase + '_K'], f[kdjColBase + '_D'], f[kdjColBase + '_J'], f[kdjColBase + '_Signal'] = KDJ(f, 
        closePeriod=parms.kdj[0], lowPeriod=parms.kdj[1], highPeriod=parms.kdj[2])
    
    return f


def VMASignal(f, parms):
    vmaP = parms.vma[0], parms.vma[1]
    #vmaColBase = 'VMA(' + str(vmaP[0]) + ', ' + str(vmaP[1]) + ')'
    vmaColBase = 'VMA'
    if (vmaColBase) not in f:
        # Make sure '_TempK_' does not exist in f!!!  
        f = f.assign(_Temp0_ = pd.Series.empty)
        f = f.assign(_Temp1_ = pd.Series.empty)
        f = f.assign(_Temp2_ = pd.Series.empty)
        f.rename(index=str, columns={'_Temp0_' : 'VMA0', 
                                     '_Temp1_' : 'VMA1', 
                                     '_Temp2_' : 'VMA_Signal'}, inplace=True)        
    fVolume = f['Volume'].as_matrix()
    #https://stackoverflow.com/questions/22993124/ta-lib-numpy-assertionerror-real-is-not-double
    fVolume = np.array(fVolume, dtype=float)
    ## volume is stored as int
    #fVolume = fVolume.astype(float)
#    f['VMA(' + str(vmaP[0]) + ')'] = talib.MA(fVolume, vmaP[0])
#    f['VMA(' + str(vmaP[1]) + ')'] = talib.MA(fVolume, vmaP[1])
    f['VMA0'] = talib.MA(fVolume, vmaP[0])
    f['VMA1'] = talib.MA(fVolume, vmaP[1])
    #title = vmaColBase
    #f.plot(y=['VMA(' + str(vmaP[0]) + ')', 'VMA(' + str(vmaP[1]) + ')'], title=title)
    
    # Define Policy
    # VMA: current day's volume surpasses its 5day and 10days moving average - BUY
    # VMA: current day's volume is lower than its 5day and 10days moving average - SELL
    # VMA: Otherwis - HOLD
    #signal = pd.DataFrame.copy(f['Close']).astype(str)
#    if (vmaColBase + '_Signal') not in f:
#        f = f.assign(_Temp_ = pd.Series(np.empty(len(f), dtype=str)))
#        f.rename(index=str, columns={'_Temp_' : (vmaColBase + '_Signal')}, inplace=True)
    
    signal = f[vmaColBase + '_Signal']
    for i in range(0, len(f)):
        volume = f['Volume'].iloc[i]
#        vma0 = f['VMA(' + str(vmaP[0]) + ')'][i]
#        vma1 = f['VMA(' + str(vmaP[1]) + ')'][i]
        vma0 = f['VMA0'].iloc[i]
        vma1 = f['VMA1'].iloc[i]
        
        if math.isnan(volume) or math.isnan(vma0) or math.isnan(vma1):
            signal.iat[i] = ''
            continue
        
        if (volume > vma0) and (vma0 > vma1):
            signal.iat[i] = 'BUY'
        elif (volume <= vma0) and (vma0 <= vma1):
            signal.iat[i] = 'SELL'
        else:
            signal.iat[i] = 'HOLD'
      
    return f


def EMASignal(f, parms):
    emaP = parms.ema[0], parms.ema[1], parms.ema[2], parms.ema[3]
#    print('emaP: ', emaP)
    #emaColBase = 'EMA(' + str(emaP[0]) + ',' + str(emaP[1]) + ',' + str(emaP[2]) + ',' + str(emaP[3]) + ')'
    emaColBase = 'EMA'
    if (emaColBase) not in f:
        # Make sure '_TempK_' does not exist in f!!!  
        f = f.assign(_Temp0_ = pd.Series.empty)
        f = f.assign(_Temp1_ = pd.Series.empty)
        f = f.assign(_Temp2_ = pd.Series.empty)
        f = f.assign(_Temp3_ = pd.Series.empty)
        f = f.assign(_Temp4_ = pd.Series.empty)
        f.rename(index=str, columns={'_Temp0_' : 'EMA0', 
                                     '_Temp1_' : 'EMA1', 
                                     '_Temp2_' : 'EMA2',
                                     '_Temp3_' : 'EMA3',
                                     '_Temp4_' : 'EMA_Signal'}, inplace=True)        

    fClose = f['Close'].as_matrix()
    #https://stackoverflow.com/questions/22993124/ta-lib-numpy-assertionerror-real-is-not-double
    fClose = np.array(fClose, dtype=float)
#    f['EMA(' + str(emaP[0]) + ')'] = talib.EMA(fClose, emaP[0])
#    f['EMA(' + str(emaP[1]) + ')'] = talib.EMA(fClose, emaP[1])
#    f['EMA(' + str(emaP[2]) + ')'] = talib.EMA(fClose, emaP[2])
#    f['EMA(' + str(emaP[3]) + ')'] = talib.EMA(fClose, emaP[3])
    f['EMA0'] = talib.EMA(fClose, emaP[0])
    f['EMA1'] = talib.EMA(fClose, emaP[1])
    f['EMA2'] = talib.EMA(fClose, emaP[2])
    f['EMA3'] = talib.EMA(fClose, emaP[3])
    #title = emaColBase
    #f.plot(y=['EMA(' + str(emaP[0]) + ')', 'EMA(' + str(emaP[1]) + ')', 'EMA(' + str(emaP[2]) + ')', 'EMA(' + str(emaP[3]) + ')'], title=title)
    
    # Define policy
    # EMA: f['Close'] > EMA(10) > EMA(30) > EMA(60) > EMA(90) - BUY
    # EMA: f['Close'] <= EMA(10) <= EMA(30) <= EMA(60) <= EMA(90) - SELL
    # EMA: Otherwise - HOLD
    #signal = pd.DataFrame.copy(f['Close']).astype(str)
#    if (emaColBase + '_Signal') not in f:
#        f = f.assign(_Temp_ = pd.Series(np.empty(len(f), dtype=str)))
#        f.rename(index=str, columns={'_Temp_' : (emaColBase + '_Signal')}, inplace=True)
    
    signal = f[emaColBase + '_Signal']
    for i in range(0, len(f)):
        close = f['Close'].iloc[i]
#        ema0 = f['EMA(' + str(emaP[0]) + ')'][i]
#        ema1 = f['EMA(' + str(emaP[1]) + ')'][i]
#        ema2 = f['EMA(' + str(emaP[2]) + ')'][i]
#        ema3 = f['EMA(' + str(emaP[3]) + ')'][i]
        ema0 = f['EMA0'].iloc[i]
        ema1 = f['EMA1'].iloc[i]
        ema2 = f['EMA2'].iloc[i]
        ema3 = f['EMA3'].iloc[i]
    
        if math.isnan(close) or math.isnan(ema0) or math.isnan(ema1) or math.isnan(ema2) or math.isnan(ema3):
            signal.iat[i] = ''
            continue    
        
        if (close > ema0) and (ema0 > ema1) and (ema1 > ema2) and (ema2 > ema3):
            signal.iat[i] = 'BUY'
        elif (close <= ema0) and (ema0 <= ema1) and (ema1 <= ema2) and (ema2 <= ema3):
            signal.iat[i] = 'SELL'
        else:
            signal.iat[i] = 'HOLD'    
            
    return f


def MACDSignal(f, parms):
    macdP = {'fastperiod': parms.macd[0], 'slowperiod': parms.macd[1], 'signalperiod': parms.macd[2]}
    #macdColBase = 'MACD(' + str(macdP['fastperiod']) + ', ' + str(macdP['slowperiod']) + ', ' + str(macdP['signalperiod']) + ')'
    macdColBase = 'MACD'
    # Prepare new columns
    if (macdColBase) not in f:
        # Make sure '_TempK_' does not exist in f!!!  
        f = f.assign(_Temp0_ = pd.Series.empty)
        f = f.assign(_Temp1_ = pd.Series.empty)
        f = f.assign(_Temp2_ = pd.Series.empty)
        f = f.assign(_Temp3_ = pd.Series.empty)
        f.rename(index=str, columns={'_Temp0_' : (macdColBase), 
                                     '_Temp1_' : (macdColBase + '_signal'), 
                                     '_Temp2_' : (macdColBase + '_hist'),
                                     '_Temp3_' : (macdColBase + '_Signal'),}, inplace=True)        

    fClose = f['Close'].as_matrix()
    #https://stackoverflow.com/questions/22993124/ta-lib-numpy-assertionerror-real-is-not-double
    fClose = np.array(fClose, dtype=float)
    f[macdColBase], f[macdColBase + '_signal'], f[macdColBase + '_hist'] = talib.MACD(fClose, 
         fastperiod=macdP['fastperiod'], 
         slowperiod=macdP['slowperiod'], 
         signalperiod=macdP['signalperiod'])
    #f[macdColBase + '_hist'] = f[macdColBase] - f[macdColBase + '_signal'] 
    #title = macdColBase
    #f.plot(y=[macdColBase, macdColBase + '_signal', macdColBase + '_hist'], title=title)
    
    # Define policy
    # MACD: histogram > 0 - BUY
    # MACD: Otherwise - SELL/HOLD???    
    signal = f[macdColBase + '_Signal']
    for i in range(0, len(f)):
        hist = f[macdColBase + '_hist'].iloc[i]
        
        if math.isnan(hist):
            #https://stackoverflow.com/questions/13784192/creating-an-empty-pandas-dataframe-then-filling-it
            signal.iat[i] = '' 
            continue
        
        if (hist > 0):
            signal.iat[i] = 'BUY'
        else:
            signal.iat[i] = 'SELL'
            
    return f


#Given an array, calculate the maximum drawdown in %.
def MaxDrawDown(f):
    #Index of the minimum value in the range
    minIdx = np.argmax(np.maximum.accumulate(f) - f) # end of the period
    #Index of the maximum value before the minimum value
    maxIdx = np.argmax(f[:minIdx]) # start of period

    mdd = (f[maxIdx] - f[minIdx]) / f[maxIdx] * 100
    return mdd


# 假定在观测区间上证指数的首日收盘价是P[1]，末日收盘价是P[n]。
# 1. 如果在观测区间没有买卖且空仓，收益为0。
# 2. 如果在观测区间没有买卖且持仓，收益为P[n]-P[1].
# 3. 如果在观测区间只有一次卖，收益为卖出的前一日的收盘价P[s]-P[1]。
# 4. 如果在观测区间只有一次买，收益为P[n] - 买入前一日的收盘价P[b]。
# 5. 如果在观测区间有多次买卖且第一次操作是买，最后一次是买，则各事件时间顺序为
#       1...b1...s1...b2...s2......bm........n
#    收益为(P[s1] - P[b1]) + (P[s2] - P[b2]) + ... + (P[n] - P[bm])
# 6. 如果在观测区间有多次买卖且第一次操作是买，最后一次是卖，则各事件时间顺序为
#       1...b1...s1...b2...s2......bm...sm...n
#    收益为(P[s1] - P[b1]) + (P[s2] - P[b2]) + ... + (P[sm] - P[bm])
# 7. 如果在观测区间有多次买卖且第一次操作是卖，最后一次是买，则各事件时间顺序为
#       1........s1...b2...s2......bm........n
#    收益为(P[s1] - P[1]) + (P[s2] - P[b2]) + ... + (P[n] - P[bm])
# 8. 如果在观测区间有多次买卖且第一次操作是卖，最后一次是卖，则各事件时间顺序为
#       1........s1...b2...s2......bm...sm...n
#    收益为(P[s1] - P[1]) + (P[s2] - P[b2]) + ... + (P[sm] - P[bm])

# 假设观测区间的第一个操作一定是买。以上条件里只有1，4，5，6是有效的。
def ComputeProfit(fFinal, signalString, logLevel=0):
    profit = 0
    tradeCount = 0
    maxDrawDown = 0
    # Locate the indices of all 'BUY'
    #next(i for i in xrange(100000) if i == 1000)
    idxBuy = [i for i, x in enumerate(fFinal[signalString]) if x == 'BUY']
    idxSell= [i for i, x in enumerate(fFinal[signalString]) if x == 'SELL']
    #print(idxBuy)
    #print(idxSell)
    
    sell = 0
    for buy in idxBuy:
        if buy < sell:
            continue;
    
        #print('Buy after  ', fFinal['Date'][buy])    
        
        # Find the next sell
        try:
            sell = next(i for i in idxSell if i > buy)
            deltaProfit = fFinal['Close'][sell] - fFinal['Close'][buy]
            profit = profit + deltaProfit        
            tradeCount = tradeCount + 2
#            fMax = max(fFinal['Close'][buy : (sell+1)])
#            fMin = min(fFinal['Close'][buy : (sell+1)])
#            drawDown = (fMax - fMin) / fMax * 100
#            if logLevel == 1:
#                print('DrawDown %8.2f high: %8.2f low: %8.2f' % (drawDown, fMax, fMin))
            drawDown = MaxDrawDown(fFinal['Close'][buy:sell+1])
            maxDrawDown = max(maxDrawDown, drawDown)
            
#            profit = pd.DataFrame(
#                        [fFinal['Date'][buy ], 
#                         fFinal['Date'][sell], 
#                         fFinal['Close'][buy], 
#                         fFinal['Close'][sell], 
#                         deltaProfit], 
#                        columns={'Buy Date', 'Sell Date', 'Buy Price', 'Sell Price', 'Profit'})            
            if logLevel == 1:
                print('BuyDate, SellDate, BuyPrice, SellPrice, Profit = ', \
                      fFinal['Date'][buy], fFinal['Date'][sell], \
                      fFinal['Close'][buy], fFinal['Close'][sell], deltaProfit)
#            print('Sell after ', fFinal['Date'][sell]) 
#            print('Incremental Profit = ', deltaProfit)
        except StopIteration:
            # No more 'SELL' after 'BUY'
            deltaProfit = fFinal['Close'][-1] - fFinal['Close'][buy]
            profit = profit + deltaProfit
            tradeCount = tradeCount + 1
#            fMax = max(fFinal['Close'][buy : ])
#            fMin = min(fFinal['Close'][buy : ])
#            drawDown = (fMax - fMin) / fMax * 100
#            if logLevel == 1:
#                print('DrawDown %8.2f high: %8.2f low: %8.2f' % (drawDown, fMax, fMin))
            drawDown = MaxDrawDown(fFinal['Close'][buy:])
            maxDrawDown = max(maxDrawDown, drawDown)
            
            if logLevel == 1:
                print('Buy Date, SellDate, BuyPrice, SellPrice, Profit = ', \
                      fFinal['Date'][buy], fFinal['Date'][-1], \
                      fFinal['Close'][buy], fFinal['Close'][-1], deltaProfit)            
#            print('Hold till  ', fFinal['Date'][sell]) 
#            print('Incremental Profit = ', deltaProfit)
            break
        
    return profit, tradeCount, maxDrawDown


# http://stackoverflow.com/q/3844948/
#def checkEqualIvo(lst):
def ListAllEqual(lst):
    return not lst or lst.count(lst[0]) == len(lst)


# Given a period of security data and indicator parameters for KDJ, MACD, EMA,
# and VMA, derive both the profit and the maximum possible profit.
# ff: security's Close, High, Low, Volume, Date data
_signalDict = {'BUY' : 1, 'HOLD' : 0, 'SELL' : -1, '' : 0}
def Profit(ff, parms, logLevel=0):
    # Parameter verification
    if parms.start >= parms.end:
        print('ERROR: The specified start date is not before the end date.')
        return -1
    
    if parms.macd[0] >= parms.macd[1]:
        print('ERROR: The specified MACD short period is larger or equal to MACD long period.')
        return -1
    
    if parms.ema[0] >= parms.ema[1]:
        print('ERROR: The specified EMA short period is larger or equal to EMA long period.')
        return -1
    
    if parms.ema[1] >= parms.ema[2]:
        print('ERROR: The specified EMA short period is larger or equal to EMA long period.')
        return -1
    
    if parms.ema[2] >= parms.ema[3]:
        print('ERROR: The specified EMA short period is larger or equal to EMA long period.')
        return -1
    
    # Compute the extra days needed prior to start so that there is no NaN between
    # start and end dates.
    leadTime = [
        parms.macd[0] + parms.macd[2],# MACD_short + MACD_ma
        parms.macd[1] + parms.macd[2],# MACD_long + MACD_ma 
        parms.kdj[0], parms.kdj[1], parms.kdj[2], 
        parms.ema[3],# The longest EMA period
        parms.vma[0], parms.vma[1]
    ]
    leadTime = max(leadTime)
    leadTime = datetime.timedelta(days=leadTime)
    
    # Verify f contains the first date
    if parms.start < (datetime.datetime.min + leadTime).date():
        print('The lead time derived from parameters are too big.')
        return -1
    
    # Subset data
    newStart = parms.start - leadTime
    if min(ff['Date']) > newStart:
        print('The original dataset does not contain enough lead time. Pleaes reduce the The lead time derived from parameters are too big.')
        return -1
    
    #f is a reference of ff    
    f = ff[(ff['Date'] >= newStart) & (ff['Date'] <= parms.end)]        

    # MACD
    f = MACDSignal(f, parms)   
    
    # EMA
    f = EMASignal(f, parms)
        
    # Volume MA
    f = VMASignal(f, parms)
    
    # KDJ
    f = KDJSignal(f, parms)
    
    # Define policy
    # If all signals are BUY, then BUY. If all signals are SELL, then SELL. Otherwise, HOLD.
    if 'Signal' not in f:
        f = f.assign(_Temp_ = pd.Series(np.empty(len(f), dtype=str)))
        f.rename(index=str, columns={'_Temp_' : 'Signal'}, inplace=True)
    
    if logLevel == 1:
        print('Date\t\tKDJ_Signal\tMACD_Signal\tEMA_Signal\tVMA_Signal\tSignal\tVolume\tVMA0\tVMA1')

    buyIdx = -1
    signal = f['Signal']
    for i in range(0, len(f)):
        sKDJ = f['KDJ_Signal'].iloc[i]
        sMACD= f['MACD_Signal'].iloc[i]
        sEMA = f['EMA_Signal'].iloc[i]
        sVMA = f['VMA_Signal'].iloc[i]
        signals = [sMACD, sKDJ, sEMA, sVMA]
        
        #---Default policy---
        #BUY if and only if every indicator is BUY.
        #SELL if and only if every indicator is SELL.
        # if '' in signals:
            # signal.iat[i] = ''
            # continue
        
        # if ListAllEqual(signals):
            # signal.iat[i] = sMACD#either BUY or HOLD or SELL
        # else:
            # signal.iat[i] = 'HOLD'
        #---Default policy---
         
        #---Weighted policy aggregation---
        #BUY when the weighted sum of indicator signals is above set threshold.
        #SELL when the weighted sum of indicator signals is below set threshold.
        #Map 'BUY', 'SELL', 'HOLD' to 1, -1, 0
        x = [_signalDict.get(i,i) for i in signals]
        #Dot product between parms.weights and x
        y = sum(i[0] * i[1] for i in zip(parms.weights, x))
        
        if y >= parms.buyThreshold:
            signal.iat[i] = 'BUY'
            
            #Only record the first BUY signal
            if buyIdx < 0:
                buyIdx = i
        elif y <= -parms.sellThreshold:
            signal.iat[i] = 'SELL'
        elif (parms.maxDrawDown < 100) and (buyIdx >= 0):
            #Max drawdown till YESTERDAY
            mdd = MaxDrawDown(f['Close'][buyIdx:i+1])
            if mdd > parms.maxDrawDown:
#                print('Previous day MDD = %f' % MaxDrawDown(f['Close'][buyIdx:i]))
                signal.iat[i] = 'SELL'
                #Reset buyIdx till the next BUY signal
                buyIdx = -1
            else:
                signal.iat[i] = 'HOLD'
        else:
            signal.iat[i] = 'HOLD'  
        #---Weighted policy aggregation---
        
        if logLevel == 1:
            print('%s\t%s\t\t%s\t\t%s\t\t%s\t\t%s\t%.0f\t%.0f\t%.0f' % 
                  (str(f['Date'].iloc[i]), sKDJ, sMACD, sEMA, sVMA, signal.iat[i],
                   f['Volume'].iloc[i], f['VMA0'].iloc[i], f['VMA1'].iloc[i]))
    
    # Compute income
    # Only care about signals between start and end.
    fFinal = f[(f['Date'] >= parms.start) & (f['Date'] <= parms.end)]
    # =============================================================================
    # signalString = macdColBase + '_Signal'
    # profit = optparms.ComputeProfit(fFinal, signalString)    
    # print('Profit[' + signalString + '] = ', profit)
    # 
    # signalString = kdjColBase  + '_Signal'
    # profit = optparms.ComputeProfit(fFinal, signalString)    
    # print('Profit[' + signalString + '] = ', profit)
    # 
    # signalString = emaColBase  + '_Signal'
    # profit = optparms.ComputeProfit(fFinal, signalString)    
    # print('Profit[' + signalString + '] = ', profit)
    # 
    # signalString = vmaColBase  + '_Signal'
    # profit = optparms.ComputeProfit(fFinal, signalString)    
    # print('Profit[' + signalString + '] = ', profit) 
    # =============================================================================
    signalString = 'Signal'
    parms.profit, parms.tradeCount, parms.drawDown = ComputeProfit(fFinal, signalString, logLevel)  
            
    return ff, fFinal, parms
    
    
def SaveSignal(f, fileName):
#    d = dict(BUY=1, HOLD=0, SELL=-1)
    
    with open(fileName, 'w', newline='') as csvfile:
        spamwriter = csv.writer(csvfile, delimiter=',', 
                                quotechar='"', quoting=csv.QUOTE_MINIMAL)
        #Header
        spamwriter.writerow(['Date'] + ['Close'] + ['Open'] + ['High'] + 
            ['Low'] + ['Volume'] + ['Signal'])
        
        for index, row in f.iterrows():
            spamwriter.writerow([row['Date'], row['Close'], row['Open'], row['High'], 
                row['Low'], row['Volume'], row['Signal']])

#        spamwriter.writerow(['Date'] + ['Close'] + ['Open'] + ['High'] + 
#            ['Low'] + ['Volume'] + ['Signal'] + ['Signal_Integer'])
#        
#        for index, row in f.iterrows():
#            spamwriter.writerow([row['Date'], row['Close'], row['Open'], row['High'], 
#                row['Low'], row['Volume'], row['Signal'], d[row['Signal']]])


